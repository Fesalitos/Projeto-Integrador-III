const express = require('express');
const path = require('path');
const { createClient } = require('@supabase/supabase-js');

// Configuração do Supabase
const SUPABASE_URL = "https://lnnrcgaqdsqhllznxcni.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxubnJjZ2FxZHNxaGxsem54Y25pIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDc5MTkxNTMsImV4cCI6MjA2MzQ5NTE1M30.d8XhfscsG3aFgJYu9l_gTcosgouBWO7w_XJw422uv8o";
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// Inicializa o app Express
const app = express();

// Servir arquivos estáticos (HTML, CSS, JS da interface de busca)
app.use(express.static(path.join(__dirname)));

// Endpoint para retornar os produtos
app.get('/api/produtos', async (req, res) => {
  try {
    const nome = req.query.nome;

    let query = supabase
      .from('products')
      .select('*');

    // Se tiver nome na query, faz busca com ilike
    if (nome) {
      query = query.ilike('name', `%${nome}%`);
    }

    const { data, error } = await query;

    if (error) throw error;
    res.json(data);
  } catch (err) {
    console.error('Erro ao buscar produtos:', err.message);
    res.status(500).json({ error: 'Erro ao buscar produtos' });
  }
});



// Inicia o servidor primeiro
app.listen(3000, () => {
  console.log('Servidor rodando em http://localhost:3000');

  // Depois que o servidor sobe, roda o scraper
  (async () => {
    try {
      console.log("🛒 Iniciando coleta de dados dos mercados...");
      await require('./sao_vicente.js');
      console.log("✅ Coleta de dados finalizada com sucesso.");
    } catch (error) {
      console.error("❌ Erro durante a coleta de dados:", error);
    }
  })();
});

