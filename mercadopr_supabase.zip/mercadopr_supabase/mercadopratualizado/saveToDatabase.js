const { getDate } = require("./getdate.js");
const { saveToSupabase } = require("./database.js");

const mercadosAvailable = ["são vicente", "Sonda"];

async function compareAndSaveToDatabase(newlyScrapedProducts, mercadoName, maxProductsToUpload) {
  if (!mercadosAvailable.includes(mercadoName)) {
    console.error(`Error: mercadoName "${mercadoName}" is not available.`);
    return;
  }

  console.log("\nIniciando comparação e salvamento...");
  console.log("Recebidos do SCRAPER:", newlyScrapedProducts.length, "produtos");

  // Remover duplicatas por nome
  const uniqueNewlyScrapedProducts = newlyScrapedProducts.filter(
    (product, index, self) =>
      index === self.findIndex((p) => p.name === product.name)
  );
  console.log("Removidos duplicados:", uniqueNewlyScrapedProducts.length, "produtos");

  // ⚠️ OBS: Aqui não comparamos com o banco porque Supabase não tem find rápido por nome como o Mongo.
  // Você pode depois melhorar isso com índices ou tabelas auxiliares.

  // Vamos só salvar todos os produtos como novos por enquanto
  const produtosParaSalvar = uniqueNewlyScrapedProducts
    .slice(0, maxProductsToUpload)
    .map(product => ({
      ...product,
      priceUpdatesCounter: 0,
      mercado: mercadoName,
      updatedHour: getDate().dateHour,
      updatedDate: getDate().dateYYYYMMDD,
    }));

  if (produtosParaSalvar.length > 0) {
    await saveToSupabase(produtosParaSalvar);
    console.log(`${produtosParaSalvar.length} produtos enviados para o Supabase ✅`);
  } else {
    console.log("Nenhum produto para salvar no Supabase.");
  }
}

module.exports = { compareAndSaveToDatabase };

module.exports = { compareAndSaveToDatabase };
