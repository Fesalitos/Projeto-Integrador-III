const { createClient } = require("@supabase/supabase-js");

// Substitua pelas suas credenciais Supabase
const SUPABASE_URL = "https://lnnrcgaqdsqhllznxcni.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxubnJjZ2FxZHNxaGxsem54Y25pIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDc5MTkxNTMsImV4cCI6MjA2MzQ5NTE1M30.d8XhfscsG3aFgJYu9l_gTcosgouBWO7w_XJw422uv8o";

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

async function saveToSupabase(data) {
  if (!data || data.length === 0) {
    console.log("Nenhum dado fornecido para salvar.");
    return;
  }

  try {
    const { error, count } = await supabase
      .from("products")
      .insert(data, { count: "exact" });

    if (error) throw error;

    console.log(`${count || data.length} produtos adicionados ao Supabase`);
  } catch (error) {
    console.error("Erro ao salvar no Supabase:", error);
  }
}

module.exports = {
  saveToSupabase,
};