const puppeteer = require("puppeteer");
const { getDate } = require("./getdate.js");
const {  } = require("./database.js");
const { compareAndSaveToDatabase } = require("./saveToDatabase.js");
const { autoScroll } = require("./autoscroll.js");

const categoriesURLs = [
  "https://www.svicente.com.br/Congelados",
  "https://www.svicente.com.br/Achocolatado-Em-Po-1",
  "https://www.svicente.com.br/Bebidas-",
  "https://www.svicente.com.br/Bebidas-Alco%C3%B3licas",
  "https://www.svicente.com.br/Bebidas-Vegetais-1",
  "https://www.svicente.com.br/Bebidas-Vegetais-3",
  "https://www.svicente.com.br/Bebidas-Vegetais-5",
  "https://www.svicente.com.br/Arroz-",
  "https://www.svicente.com.br/Azeites-1",
  "https://www.svicente.com.br/Iogurtes-E-Leite-Fermentado",
  "https://www.svicente.com.br/Iogurte-Liquido-E-Polpa-1",
  "https://www.svicente.com.br/Iogurtes-Funcionais-E-Proteicos-1",
  "https://www.svicente.com.br/Iogurtes-Infantil-1",
  "https://www.svicente.com.br/Iogurtes-Light-E-Zero.-Zero-Lactose-1",
  "https://www.svicente.com.br/Iogurtes-Naturais-E-Saborizados-1",
  "https://www.svicente.com.br/Carnes.-Aves-E-Peixes",
  "https://www.svicente.com.br/Carnes",
  "https://www.svicente.com.br/Carnes-Especiais-1",
  "https://www.svicente.com.br/Carnes-Especiais-2",
  "https://www.svicente.com.br/Carne-De-Sol-Granel",
  "https://www.svicente.com.br/Caf%C3%A9s-1",
  "https://www.svicente.com.br/Milho-1",
  "https://www.svicente.com.br/Ervilha-E-Seletas-1",
  "https://www.svicente.com.br/Palmito-1",
  "https://www.svicente.com.br/Azeitona-1",
];

let extractedProducts = [];

function addProductDetails(products) {
  const { dateHour, dateDDMMYY } = getDate();
  return products.map(product => ({
    ...product,
    mercado: "são vicente",
    updatedHour: dateHour,
    updatedDate: dateDDMMYY,
  }));
}

async function setupBrowser() {
  const browser = await puppeteer.launch({ headless: false });
  const page = await browser.newPage();

  await page.setUserAgent(
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.71 Safari/537.36"
  );
  await page.setViewport({ width: 1303, height: 980 });
  page.setDefaultNavigationTimeout(60000);

  return { browser, page };
}

async function removeDuplicates() {
  extractedProducts = extractedProducts.filter(
    (product, index, self) => index === self.findIndex(p => p.name === product.name)
  );
}

async function scrapeCategory(categoryURL, page) {
  try {
    const categoria = decodeURIComponent(categoryURL.split(".br/")[1].replace(/-/g, " ").replace(/\d+$/, "").trim());

    console.log("\nNavigating to:", categoryURL);
    await page.goto(categoryURL, { waitUntil: "networkidle2", timeout: 60000 });

    const productSelector = ".productCard__container";
    await page.waitForSelector(productSelector, { timeout: 60000 });

    console.log("Scrolling...");
    await autoScroll(page);

    const products = await page.$$eval(productSelector, (productElements, categoria) => {
      return productElements.map(productElement => {
        const nameElem = productElement.querySelector(".productCard__title");
        const priceElem = productElement.querySelector(".productPrice__price");
        const anchor = productElement.querySelector("a");
        const imgElem = productElement.querySelector("img");

        const name = nameElem?.textContent?.trim() || "N/A";
        const priceRaw = priceElem?.textContent?.trim() || "R$ 0,00";
        const price = parseFloat(priceRaw.replace("R$", "").replace(".", "").replace(",", "."));

        const productLink = anchor?.href || "N/A";
        const imageUrl = imgElem?.getAttribute('src') || imgElem?.getAttribute('data-src') || 'N/A';


        return {
          name,
          price,
          productLink,
          imageUrl,
          categoria,
        };
      });
    }, categoria);

    extractedProducts.push(...products);
    console.log("Produtos extraídos:", products.length);
  } catch (error) {
    console.error(`Erro ao extrair a categoria [${categoryURL}]:`, error.message);
  }
}


(async () => {
  const { browser, page } = await setupBrowser();

  for (const categoryURL of categoriesURLs) {
    await scrapeCategory(categoryURL, page);
  }

  console.log("\nTotal antes dos duplicados:", extractedProducts.length);
  await removeDuplicates();
  console.log("Total após remover duplicados:", extractedProducts.length);

  await browser.close();

  extractedProducts = addProductDetails(extractedProducts);

  if (extractedProducts.length > 0) {
    await compareAndSaveToDatabase(extractedProducts, "são vicente", 5000);
    console.log("\nFinalizado com sucesso ✅");
  } else {
    console.log("\nNenhum produto extraído para salvar ❌");
  }

  
})();
