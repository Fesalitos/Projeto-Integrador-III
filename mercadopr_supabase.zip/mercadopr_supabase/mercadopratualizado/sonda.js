// sonda_scraper.js
const puppeteer = require("puppeteer");
const { getDate } = require("./getdate.js");
const { compareAndSaveToDatabase } = require("./saveToDatabase.js");
const { autoScroll } = require("./autoscroll.js");

const sondaCategoriesURLs = [
  "https://www.sondadelivery.com.br/delivery/categoria/Arroz2",
  "https://www.sondadelivery.com.br/delivery/categoria/Cafes,_Chas_e_Achocolatados",
  "https://www.sondadelivery.com.br/delivery/categoria/Bebidas2",
  "https://www.sondadelivery.com.br/delivery/categoria/Bebidas-",
  "https://www.sondadelivery.com.br/delivery/categoria/Mercearia-l",
  "https://www.sondadelivery.com.br/delivery/categoria/Mercearia-",
  "https://www.sondadelivery.com.br/delivery/categoria/Frios,_Laticinios_e_Iogurtes",
  "https://www.sondadelivery.com.br/delivery/categoria/Carnes,_Aves_e_Peixes",
  "https://www.sondadelivery.com.br/delivery/categoria/Carnes-exoticas",
  "https://www.sondadelivery.com.br/delivery/categoria/Padaria-s"
];

let extractedProducts = [];

function addProductDetails(products) {
  const { dateHour, dateDDMMYY } = getDate();
  return products.map(product => ({
    ...product,
    mercado: "Sonda",
    updatedHour: dateHour,
    updatedDate: dateDDMMYY,
  }));
}

async function setupBrowser() {
  const browser = await puppeteer.launch({ headless: false });
  const page = await browser.newPage();
  await page.setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.71 Safari/537.36");
  await page.setViewport({ width: 1300, height: 900 });
  page.setDefaultNavigationTimeout(60000);
  return { browser, page };
}

async function removeDuplicates() {
  extractedProducts = extractedProducts.filter(
    (product, index, self) => index === self.findIndex(p => p.name === product.name)
  );
}

async function scrapeSondaCategory(categoryURL, page) {
  try {
    const categoria = decodeURIComponent(categoryURL.split('/categoria/')[1].replace(/[_,-]/g, ' ').trim());

    console.log("\nNavegando para:", categoryURL);
    await page.goto(categoryURL, { waitUntil: "networkidle2", timeout: 60000 });

    const productSelector = '.product--info';
    await page.waitForSelector(productSelector, { timeout: 60000 });
    await autoScroll(page);

    const products = await page.$$eval(productSelector, (items, categoria) => {
      return items.map(item => {
        const name = item.querySelector('.product--title .tit')?.textContent?.trim() || 'N/A';
        const priceRaw = item.querySelector('.product--price .price .int span')?.textContent?.trim() || '0,00';
        const price = parseFloat(priceRaw.replace('.', '').replace(',', '.')) || 0;

        const linkElem = item.closest('.product--info').querySelector('a.js-link-produto');
        const productLink = linkElem ? "https://www.sondadelivery.com.br" + linkElem.getAttribute('href') : "N/A";

        const imgElem = item.closest('.product--info').previousElementSibling.querySelector('img');
        const imageUrl = imgElem?.getAttribute('data-srcset') || imgElem?.getAttribute('srcset') || imgElem?.src || 'N/A';

        return { name, price, productLink, imageUrl, categoria };
      });
    }, categoria);

    extractedProducts.push(...products);
    console.log(`Produtos extraídos da categoria [${categoria}]:`, products.length);
  } catch (error) {
    console.error(`Erro ao extrair a categoria [${categoryURL}]:`, error.message);
  }
}

(async () => {
  const { browser, page } = await setupBrowser();

  for (const categoryURL of sondaCategoriesURLs) {
    await scrapeSondaCategory(categoryURL, page);
  }

  console.log("\nTotal de produtos extraídos:", extractedProducts.length);
  await removeDuplicates();
  console.log("Total após remover duplicados:", extractedProducts.length);

  extractedProducts = addProductDetails(extractedProducts);

  if (extractedProducts.length > 0) {
    await compareAndSaveToDatabase(extractedProducts, "Sonda", 5000);
    console.log("\nFinalizado com sucesso ✅");
  } else {
    console.log("\nNenhum produto extraído para salvar ❌");
  }

  await browser.close();
})();
