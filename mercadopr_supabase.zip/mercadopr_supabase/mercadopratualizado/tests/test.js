 categoriesURLs = [
    "https://www.angeloni.com.br/super/c/congelados/_/N-ha9qgj",
    "https://www.angeloni.com.br/super/c/mercearia/achocolatado-em-po/_/N-1s0nch5"
  ]



  //Angeloni
  {
    name: 'Achocolatado em Pó Toddy Light Pote 380g',
    imageUrl: '//statics.angeloni.com.br/super/files/produtos/115
    productLink: 'https://www.angeloni.com.br/super/p/achocolatad159026',
    price: 17.9
  },

  _id
  65142c925269c9d47b6d1c57
  id
  5010
  name
  "Refrigerante Guaraná Lata 350ml - Antarctica"
  photo
  "refrigerante-guarana-lata-350ml-antarctica-un-01232a2e5d.jpg"
  category
  "Refrigerantes"
  type
  "Guaraná"
  brand
  "Antarctica"
  weight
  "350ml"
  packaging
  "Lata"
  
  providers
  Array
  
  0
  Object
  name
  "ATACADÃO CD ITAJAÍ"
  providerId
  73989430
  logo
  "atacadao-itajai.png"
  delivery_time_in_days
  10
  
  prices
  Array
  
  0
  Object
  id
  19149548
  minimum_quantity
  12
  price
  2.7899999999999996
  unit
  "UN"
  stock_count
  10000
  slug
  "refrigerante-guarana-antarctica-lata-350ml"
  categoryNumber
  65
  mercado
  "atacadao"
  cityURL
  "SC-Blumenau"